import java.sql.*;	
class  callsp
{
	public static void main(String[] args) 
	{

		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:sqldsn","sql2005","sql2005");

CallableStatement cs = con.prepareCall("{call exec showproductlist}");
ResultSet rs = cs.executeQuery();
	while(rs.next())
			{	
	System.out.print(rs.getString(1));
	System.out.print(rs.getString(2));
	System.out.print(rs.getString(3));
	System.out.print(rs.getString(4));
	System.out.println("");

		}


		System.out.println("Query Fired");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
