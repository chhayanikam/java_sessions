import java.sql.*;
import java.io.*;
class dml
	{
public static void main(String af[]) throws Exception
	{
	 try {
// get the driver info 
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
// creating the connection
Connection con = DriverManager.getConnection("jdbc:odbc:sql32","sa","sql#2008");
	 //con.setAutoCommit(false);	
         Statement st = con.createStatement();
st.executeUpdate("insert into cardetails VALUES           ('102','maruti','des1',5698899)");
//st.executeUpdate("delete from cardetails  where modelno='101' ");
//st.executeUpdate("update emp set sal=5000 where empno=101");
con.commit();
	System.out.println("Query executed");
	st.close();
	con.close();	
	}
	catch(Exception e)
	{
	System.out.println("Exception " + e);
	}
	}
	}
