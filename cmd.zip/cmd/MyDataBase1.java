import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;	
class  MyDataBase1 extends JFrame implements ActionListener
{
 		PreparedStatement pstmt;
		Connection con; 
		ResultSetMetaData rsmd;
		ResultSet rs;
		Statement stmt;
		JLabel lbl_1,lbl_2,lbl_3,lbl_4,lbl_5,lbl_6,lbl_7,lbl_8,lbl_9;
		JButton btn_ok,btn_close,btn_next;
		JTextField txt_id,txt_name,txt_phone;

		MyDataBase1(String title)
		{
			super(title);			

			Container contentpane = getContentPane();
			contentpane.setLayout(null);
			
			lbl_1 = new JLabel("Code");
			lbl_1.setBounds(50,50,100,20);
			contentpane.add(lbl_1);
			txt_id = new JTextField();
			txt_id.setBounds(170,50,100,20);
			contentpane.add(txt_id);

			lbl_2 = new JLabel("Name");
			lbl_2.setBounds(50,80,100,20);
			contentpane.add(lbl_2);
			txt_name = new JTextField();
			txt_name.setBounds(170,80,100,20);
			contentpane.add(txt_name);

			lbl_3 = new JLabel("Phone");
			lbl_3.setBounds(50,110,100,20);
			contentpane.add(lbl_3);
			txt_phone = new JTextField();
			txt_phone.setBounds(170,110,100,20);
			contentpane.add(txt_phone);

			btn_ok = new JButton("Insert");
			btn_ok.setActionCommand("INSERT");
			btn_ok.addActionListener(this);
			btn_ok.setBounds(80,150,100,20);
			contentpane.add(btn_ok);

			btn_close = new JButton("Close");
			btn_close.setActionCommand("CLOSE");
			btn_close.addActionListener(this);
			btn_close.setBounds(200,150,100,20);
			contentpane.add(btn_close);


			lbl_4 = new JLabel("XXXXXX");
			lbl_4.setBounds(100,200,100,20);
			contentpane.add(lbl_4);
			lbl_5 = new JLabel("XXXXXX");
			lbl_5.setBounds(200,200,100,20);
			contentpane.add(lbl_5);

			lbl_6 = new JLabel("XXXXXX");
			lbl_6.setBounds(100,230,100,20);
			contentpane.add(lbl_6);
			lbl_7 = new JLabel("XXXXXX");
			lbl_7.setBounds(200,230,100,20);
			contentpane.add(lbl_7);

			lbl_8 = new JLabel("XXXXXX");
			lbl_8.setBounds(100,260,100,20);
			contentpane.add(lbl_8);
			lbl_9 = new JLabel("XXXXXX");
			lbl_9.setBounds(200,260,100,20);
			contentpane.add(lbl_9);

			btn_next = new JButton("NEXT");
			btn_next.setActionCommand("NEXT");
			btn_next.addActionListener(this);
			btn_next.setBounds(150,300,100,20);
			contentpane.add(btn_next);

			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con = DriverManager.getConnection("jdbc:odbc:javadsn","sa","");
				stmt = con.createStatement();
//				pstmt = con.prepareStatement("Insert into Bharat values (?,?,?)");

				rs =  stmt.executeQuery("select * from emp");
				rsmd = rs.getMetaData();
				lbl_4.setText(rsmd.getColumnName(1));
				lbl_6.setText(rsmd.getColumnName(2));
				lbl_8.setText(rsmd.getColumnName(3));
				rs.next();

				lbl_5.setText(rs.getString(1));
				lbl_7.setText(rs.getString(2));
				lbl_9.setText(rs.getString(3));

			}catch(Exception ea){}
			

			setSize(400,400);
			setVisible(true);
		}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand() == "INSERT")
		{
			try
			{				pstmt.setInt(1,Integer.parseInt(txt_id.getText().trim()));
				pstmt.setString(2,txt_name.getText().trim());
				pstmt.setInt(3,Integer.parseInt(txt_phone.getText()));
				pstmt.executeUpdate();
			}catch(Exception em){}
			JOptionPane.showMessageDialog(this,"Record   Saved!!!");
		}

		if(e.getActionCommand() == "NEXT")
		{
			try
			{
				rs.next();
				lbl_5.setText(rs.getString(1));
				lbl_7.setText(rs.getString(2));
				lbl_9.setText(rs.getString(3));
		    }catch(Exception ae){}
		}


		if(e.getActionCommand() == "CLOSE")
		{
			System.exit(0);
		}
	}

		public static void main(String args[])
		{
			MyDataBase1 window = new MyDataBase1("Insert Recors");
		}
}


