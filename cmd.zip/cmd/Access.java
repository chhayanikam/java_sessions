import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Access extends Frame implements ActionListener
{
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    Button b1,b2,b3,b4;
    Label l1,l2,l3,l4,l5,l6,l7,l8;
    
    public Access()
    {
        super("Access Database Example");
        setSize(800,500);
        setLayout(null);

        l1 = new Label("Field 1");
        l1.setBounds(100,100,100,30);
        add(l1);

        l2 = new Label();
        l2.setBounds(250,100,100,30);
        add(l2);

        l3 = new Label("Field 2");
        l3.setBounds(100,150,100,30);
        add(l3);

        l4 = new Label();
        l4.setBounds(250,150,100,30);
        add(l4);

        l5 = new Label("Field 3");
        l5.setBounds(100,200,100,30);
        add(l5);

        l6 = new Label();
        l6.setBounds(250,200,100,30);
        add(l6);

        l7 = new Label("Message");
        l7.setBounds(100,250,100,30);
        add(l7);

        l8 = new Label();
        l8.setBounds(250,250,250,30);
        add(l8);

        b1 = new Button("Next");
        b1.setBounds(100,300,100,30);
        b1.addActionListener(this);
        add(b1);

        b2 = new Button("Previous");
        b2.setBounds(150,300,100,30);
        b2.addActionListener(this);
        add(b2);

        b3 = new Button("First");
        b3.setBounds(300,300,100,30);
        b3.addActionListener(this);
        add(b3);

        b4 = new Button("Last");
        b4.setBounds(450,300,100,30);
        b4.addActionListener(this);
        add(b4);

        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                dispose();
                System.exit(0);
            }
        });

        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:MAD");
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery("Select * from products");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return;
        }

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b1)
        {
            try
            {
                rs.next();
            }
            catch(Exception e)
            {
                l8.setText(e.toString());
            }
            setValues();
        }

        if(ae.getSource()==b2)
        {
            try
            {
                rs.previous();
            }
            catch(Exception e)
            {
                l8.setText(e.toString());
            }
            
            setValues();
        }

        if(ae.getSource()==b3)
        {
            try
            {
                rs.first();
            }
            catch(Exception e)
            {
                l8.setText(e.toString());
            }
            setValues();
        }

        if(ae.getSource()==b4)
        {
            try
            {
                rs.last();
            }
            catch(Exception e)
            {
                l8.setText(e.toString());
            }
            
            setValues();
        }
    }

    public void setValues()
    {
        try
        {
            l2.setText(rs.getString(1));
            l4.setText(rs.getString(2));
            l6.setText(rs.getString(3));
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return;
        }

    }

    public static void main(String args[])
    {
        new Access();
    }
}
