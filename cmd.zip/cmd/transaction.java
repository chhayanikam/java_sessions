import java.sql.*;
//import java.io.*;
class transaction
{
public static void main(String af[]) 
{
Connection con=null;
	 try {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con = DriverManager.getConnection("jdbc:odbc:testdsn","sa","sql#2008");
 con.setAutoCommit(false); // turns off the implicit transaction	
 Statement st = con.createStatement();
 
st.executeUpdate("insert into products values(4,'item1',3400)");
st.executeUpdate("delete from  products where productid=5");

con.commit(); // make the changes permanent in the table


	System.out.println("inserted");
	st.close();
	con.close();	
	}
	catch(SQLException e)
	{
	 //con.rollback(); // undo the transaction
	System.out.println("Exception " + e);
	}
	catch(Exception ee)
	{
	System.out.println("Exception " + ee);
	}
	}
	}
