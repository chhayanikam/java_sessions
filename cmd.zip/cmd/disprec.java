// step 1
import  java.sql.*;

public class disprec
{	public static void main(String args[])
	{	
		try
		{
	// step 2 --initilize the type 1 driver -- type 1 helps to connect any type of db (sql server,Oracle,access) 
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

        // step 3-- retrieve the connection by calling the getConnection method of DriverManager Interface
// store the reference in the Connection interface

Connection  con = DriverManager.getConnection("jdbc:odbc:Airlines","sa","sql#2008");
//Connection  con = DriverManager.getConnection("jdbc:odbc:Airlines");

// step 4 --- call the createStatement method by using con reference
// returns a reference of type Statement interface
Statement stmt = con.createStatement();

//ResultSet rs= stmt.executeQuery("select * from  Flight_det ");
ResultSet rs= stmt.executeQuery("select * from " + args[0]);
			while(rs.next()) // iterate through the resultSet till u reach the EO resultset
			{	
			System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) );
			}
}catch(SQLException e){System.out.println("Sql Exception"+e);}
catch(ClassNotFoundException e1){System.out.println("Class not found");}
catch(Exception e1){System.out.println("Some other error...");}
	}
}
