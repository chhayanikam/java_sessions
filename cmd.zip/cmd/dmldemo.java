// demo to execute dml on the table
import java.sql.*; // must
import java.io.*;

class dmldemo
	{
	public static void main(String af[]) throws Exception
	{
	 try {
// get the driver info -- step 1
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); // type1

// creating the connection --step 2
Connection con = DriverManager.getConnection("jdbc:odbc:lib_dsn","sa","sql#2008");


// step 3 create a statement	
 Statement st = con.createStatement();
 st.executeUpdate("insert into members values(5,'shubham','888888')");
 st.executeUpdate("insert into members values(3,'shubham','888888')");
 st.executeUpdate("insert into members values(4,'shubham','888888')");

//st.executeUpdate("delete from cardetails  where modelno='101' ");
//st.executeUpdate("update emp set sal=5000 where empno=101");

	System.out.println("Query executed");
	st.close();
	con.close();	
	}
	catch(Exception e)
	{
	System.out.println("Exception " + e);
	}
	}
	}
