import java.sql.*;	

class  MyDataBase
{
	
	public static void main(String[] args) 
	{
	ResultSet rs;
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:testdsn","sa","sql#2008");
			Statement stmt = con.createStatement();
			//estmt.executeUpdate(args[0]);
			//stmt.executeUpdate("create table student(id int,name varchar(20),phone int);");


    		rs =  stmt.executeQuery("select * from " + args[0]);

		ResultSetMetaData rsmd = rs.getMetaData();
		int cols = rsmd.getColumnCount();
		// print the headings of the table
		for(int i=1;i<=cols;i++)
		{System.out.print(rsmd.getColumnName(i)+"\t");}

System.out.println("");
System.out.println("---------------------------------------------------------------");

// while loop to print the records
// iterate the resultset till records are avaible
			while(rs.next()) 
			{
			// read all col data
			for(int j=1;j<=cols;j++)
			{
			System.out.print(rs.getString(j) + "\t");
		
			}
			System.out.println("");
			}
			System.out.println("Query Fired");
		}


		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
