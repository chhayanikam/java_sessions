import java.awt.*;
import java.awt.event.*;
import  java.sql.*;
public class Joindemo
{	public static void main(String args[])
	{	
		try
		{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
Connection  con = DriverManager.getConnection("jdbc:odbc:rupesh_dsn","sa","");
Statement stmt = con.createStatement();
ResultSet rs= stmt.executeQuery("select empno,empname,sal,dname from emp,dept where emp.deptno = dept.deptno");
			while(rs.next())
			{	
	System.out.println(rs.getString(1));
	System.out.println(rs.getString(2));
		System.out.println(rs.getString(3));
		System.out.println(rs.getString(4));
			}
}catch(SQLException e){System.out.println("Sql Exception"+e);}
catch(ClassNotFoundException e1){System.out.println("Class not found");}
	}
}
