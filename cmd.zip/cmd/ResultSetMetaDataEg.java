import java.sql.*;	

class  ResultSetMetaDataEg
{	
	public static void main(String[] args) 
	{
	ResultSet rs;
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        	//Connection con = DriverManager.getConnection("jdbc:odbc:xe","hr","hr"); // for oracle
			
Connection con = DriverManager.getConnection("jdbc:odbc:advdsn","sa","sql#2008");
Statement stmt = con.createStatement();
	
rs = stmt.executeQuery("select * from " + args[0]);
	
ResultSetMetaData rsmd = rs.getMetaData();  // structure of the resultset
int cols = rsmd.getColumnCount(); // return the number of columns in the resultset
// first for loop is used to print column headings		
		for(int i=1;i<=cols;i++)
		{
		System.out.print(rsmd.getColumnName(i)+"\t");
		}
System.out.println(" ");
System.out.println("---------------------------------------------------------------------");
 // iterate through all the records in the resultset
	
			while(rs.next()) // iterate through the rows
			{
			         // prints the column contents
				for(int j=1;j<=cols;j++)
				System.out.print(rs.getString(j) + "\t");
				System.out.println("");
			
			}
			System.out.println("Query Fired");
		}


		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
