// exceutes precompiled queries
import java.sql.*;	
class  preparecall
{
	public static void main(String[] args) 
	{
		int dno_to_del=2;
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection		("jdbc:odbc:AirLines","sa","sql#2008");

// PreparedStatement -- is a interface name that helps to create paramaterized query
	PreparedStatement updateQuery = con.prepareStatement(
	"update flight_det set source=? where flightid=?");
		
	//take city and dno from user

	updateQuery.setString(1,"Mumbai"); 
//	updateQuery.setInt(2,2); 
	updateQuery.setString(2,"F002"); 
	PreparedStatement delq = con.prepareStatement("delete from flight_det where flightid=?");
	delq.setString(1,"F003"); 

	
/*
PreparedStatement updateSales = con.prepareStatement(
	"update dbo.demo set salesamt=9000 ,yosales=2014 where employeeid=101");
*/
	/* use setString() for varchar col ,use setDouble for float setInt for int	*/

	updateQuery.executeUpdate();
	delq.executeUpdate();
	System.out.println("Record deleted");	
	System.out.println("Query Fired");

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
