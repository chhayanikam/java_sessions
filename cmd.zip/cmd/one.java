import java.awt.* ;
import java.sql.* ;
import java.awt.event.* ;

class one extends Frame implements ActionListener
{
  Connection c ;
  CallableStatement st ;
  Button b ;
  Label l1,l2 ;
  TextField tf ;
  public one()
  {
    super("MyDEmo") ;
    setSize(800,400) ;
    setLayout(null);

    tf = new TextField() ;
    tf.setBounds(50,50,100,30) ;
    add(tf) ;

    b = new Button("Execute") ;
    b.setBounds(50,130,100,30) ;
    b.addActionListener(this) ;
    add(b) ;

    l1 = new Label() ;
    l1.setBounds(50,200,100,30) ;
    l1.setBackground(Color.cyan) ;
    add(l1) ;

    l2 = new Label() ;
    l2.setBounds(250,200,100,30) ;
    l2.setBackground(Color.cyan) ;
    add(l2) ;

    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent we)
      {
        dispose() ;
        System.exit(0) ;
      }
    });
    connect() ;
  }
  public void connect()
  {
    try
    {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver") ;
    c = DriverManager.getConnection("jdbc:odbc:priya","scott","tiger");
    st = c.prepareCall("{call fun(?,?,?)}");
    }
    catch(Exception e)
    {
      e.printStackTrace(); 
    }
  }
  public void actionPerformed(ActionEvent ae)
  {
    if(ae.getSource()==b)
    {
      try
      {
         st.setInt(1,Integer.parseInt(tf.getText().trim())) ;
         st.registerOutParameter(2,Types.CHAR);
         st.registerOutParameter(3,Types.INTEGER);
         st.executeUpdate() ;
         l1.setText(st.getString(2)) ;
         l2.setText(Integer.toString(st.getInt(3))) ;
      }
      catch(Exception e)
      {
        e.printStackTrace() ;
      }
    }
  }
  public static void main(String a[])
  {
    new one().show() ;
  }
}
