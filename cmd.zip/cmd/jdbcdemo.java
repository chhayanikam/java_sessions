import java.sql.*;	

class  jdbcdemo
{
	
	public static void main(String[] args) 
	{
	ResultSet rs;
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:chk1","sa","sql#2008");
			Statement stmt = con.createStatement();
			//estmt.executeUpdate(args[0]);
			//stmt.executeUpdate("create table student(id int,name varchar(20),phone int);");

    		rs =  stmt.executeQuery("select * from emp");
		

			while(rs.next())
			{	
				// rs.getString(columnindex) begins with 1					System.out.println(rs.getString("depno") );
			}
			System.out.println("Query Fired");
		}


		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
