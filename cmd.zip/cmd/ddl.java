import java.sql.*;	
class  ddl
{
	public static void main(String[] args) 
	{

		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:jaccess","","");
		Statement stmt = con.createStatement();
		stmt.execute("create table myinfo (myid int,name char(30),phone int);");
		System.out.println("Query Fired");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
