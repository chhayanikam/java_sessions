import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;	

class  MyDataBase2 extends JFrame implements ActionListener
{
		Connection con; 
		ResultSetMetaData rsmd;
		ResultSet rs;
		Statement stmt;
		JLabel lbl_1,lbl_2,lbl_3,lbl_4,lbl_5,lbl_6;
		JButton btn_first,btn_last,btn_next,btn_prior,btn_close;

		MyDataBase2(String title)
		{
			super(title);			

			Container contentpane = getContentPane();
			contentpane.setLayout(null);

			lbl_1 = new JLabel("XXXXXX");
			lbl_1.setBounds(50,50,100,20);
			contentpane.add(lbl_1);
			lbl_2 = new JLabel("XXXXXX");
			lbl_2.setBounds(200,50,100,20);
			contentpane.add(lbl_2);

			lbl_3 = new JLabel("XXXXXX");
			lbl_3.setBounds(50,80,100,20);
			contentpane.add(lbl_3);
			lbl_4 = new JLabel("XXXXXX");
			lbl_4.setBounds(200,80,100,20);
			contentpane.add(lbl_4);

			lbl_5 = new JLabel("XXXXXX");
			lbl_5.setBounds(50,110,100,20);
			contentpane.add(lbl_5);
			lbl_6 = new JLabel("XXXXXX");
			lbl_6.setBounds(200,110,100,20);
			contentpane.add(lbl_6);

			btn_first = new JButton("<<");
			btn_first.setActionCommand("FIRST");
			btn_first.addActionListener(this);
			btn_first.setBounds(80,150,50,20);
			contentpane.add(btn_first);

			btn_prior = new JButton("<");
			btn_prior.setActionCommand("PRIOR");
			btn_prior.addActionListener(this);
			btn_prior.setBounds(150,150,50,20);
			contentpane.add(btn_prior);

			btn_next = new JButton(">");
			btn_next.setActionCommand("NEXT");
			btn_next.addActionListener(this);
			btn_next.setBounds(220,150,50,20);
			contentpane.add(btn_next);

			btn_last = new JButton(">>");
			btn_last.setActionCommand("LAST");
			btn_last.addActionListener(this);
			btn_last.setBounds(290,150,50,20);
			contentpane.add(btn_last);
			btn_close = new JButton("Close");
			btn_close.setActionCommand("CLOSE");
			btn_close.addActionListener(this);
			btn_close.setBounds(80,180,250,20);
			contentpane.add(btn_close);
			try
			{
   			   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
               con = DriverManager.getConnection("jdbc:odbc:chhdsn");
               stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
				rs =  stmt.executeQuery("select * from emp");

				rsmd = rs.getMetaData();
				lbl_1.setText(rsmd.getColumnName(1));
				lbl_3.setText(rsmd.getColumnName(2));
				lbl_5.setText(rsmd.getColumnName(3));
				rs.next();
				setValues();
			}catch(Exception ea){}

			setSize(400,400);
			setVisible(true);
		}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand() == "FIRST")
		{
            try   {   rs.first();        }
            catch(Exception e1)  {  }
            setValues();
		}

		if(e.getActionCommand() == "PRIOR")
		{
            try   {   rs.previous();       }
            catch(Exception e2)  {  }
            setValues();
		}

		if(e.getActionCommand() == "NEXT")
		{
            try   {   rs.next();       }
            catch(Exception e3)  {  }
            setValues();

		}

		if(e.getActionCommand() == "LAST")
		{
            try   {   rs.last();       }
            catch(Exception e4)  {  }
            setValues();
		}

		if(e.getActionCommand() == "CLOSE")
		{
			System.exit(0);
		}
	}

    public void setValues()
    {
        try
        {
            lbl_2.setText(rs.getString(1));
            lbl_4.setText(rs.getString(2));
            lbl_6.setText(rs.getString(3));
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return;
        }
}
		public static void main(String args[])
		{
			MyDataBase2 window = new MyDataBase2("Move Recors");
		}
}
