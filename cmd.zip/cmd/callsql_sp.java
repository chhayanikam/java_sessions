import java.sql.*;	
class  callsqlsp
{
   public static void executeStoredProcedure(Connection con)
 {
   try {
      CallableStatement cstmt = con.prepareCall("{call 		dbo.GetImmediateManager(?,?)}");
      cstmt.setInt(1, 70);
      cstmt.registerOutParameter(2, java.sql.Types.INTEGER);
      cstmt.execute(); // to call sp
      System.out.println("MANAGER ID: " + cstmt.getInt(2));
   }
   catch (Exception e) 
   {
      e.printStackTrace();
   }
}
	public static void main(String[] args) 
	{
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:odbc:testdsn","sa","sql#2008");
executeStoredProcedure(con);
System.out.println("proc called");
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
