/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Sorting;

import java.util.*; // to use the collection classes

class ComparableStudent implements Comparable<ComparableStudent>{
private String name;
private long id = 0;
private double gpa = 0.0;

public ComparableStudent(String name, long id, double gpa)
{
this.name=name;
this.id=id;
this.gpa=gpa;
}
public String getName()
{ 
return this.name; 
}
// Additional code here
public int compareTo(ComparableStudent s)
{
// sorting on the name
int result = this.name.compareTo(s.getName());
if (result > 0) 
{ 
return -1; // if first string greater than second
}
else if (result < 0)
{ return  1; // if second is greater than first
 }
else {
 return 0;  // if both the strings are equal
}
}
}

class CompareEg
{
 public static void main(String a[])
 {
	TreeSet StudentSet=new TreeSet();
	StudentSet.add(new ComparableStudent("Komal",101,4.99));
	StudentSet.add(new ComparableStudent ("Celina",101,3.8));
	StudentSet.add(new ComparableStudent ("Aritra",101,2.33));
	StudentSet.add(new ComparableStudent ("Naga",101,2.34));

Object [] sarray= StudentSet.toArray();
ComparableStudent s;
for(Object obj:sarray)
{
  s=(ComparableStudent)obj; // type casting
 //System.out.printf("name=%s \n",s.getName());	
  System.out.println(s.getName());
}

}
}
