/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Sorting;

import java.util.*;
// while using comparator interface the class structure is kept sepearate
 class Student 
{
private String name; 
private long id = 0;
 private double gpa = 0.0;
 
public Student(String name, long id, double gpa){
this.name=name;
this.id=id;
this.gpa=gpa;

}
public String getName(){ return this.name; }
public double getGpa(){ return this.gpa ;}
}

class StudentSortName implements Comparator<Student>{

    public int compare(Student s1, Student s2){
int result = s1.getName().compareTo(s2.getName());
if (result != 0) {
 return result;
}
else
{
return 0; // Or do more comparing
}
}
}

 class StudentSortGpa implements Comparator<Student>
{
public int compare(Student s1, Student s2)
{
if (s1.getGpa() < s2.getGpa())
 { 
return -1; 
}
else if (s1.getGpa() > s2.getGpa()) 
{ 
return 1; 
}
else 
{
return 0; 
}
}
}

class ComparetorEg 
{
 public static void main(String a[])
 {
List<Student> studentList = new ArrayList<>(3);
Comparator<Student> sortName = new StudentSortName();
Comparator<Student> sortGpa = new StudentSortGpa();
// Initialize list here
studentList.add(new Student("Zara",100,900.88));
studentList.add(new Student("Swara",100,900.88));
studentList.add(new Student("Allen",100,1000.88));
// apply the sort
//Collections.sort(List, sortclass);
Collections.sort(studentList, sortName);
for(Student student:studentList){
System.out.println(student.getName());
}
Collections.sort(studentList, sortGpa);
for(Student student:studentList){
System.out.println(student.getName() + " " +  student.getGpa());
}


}
}