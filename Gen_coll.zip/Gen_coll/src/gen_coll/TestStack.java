/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gen_coll;
import java.util.*;
/**
 *
 * @author MRuser
 */
public class TestStack
{
public static void main(String[] args){
Deque<String> stack = new ArrayDeque<>();
stack.push("one");
stack.push("two");
stack.push("three");
System.out.println(stack.size()); // total no of items in the collection
int size = stack.size() - 1; // to get the topmost index
while (size >= 0 ) {
System.out.println(stack.pop());
size--;
}
}
}
