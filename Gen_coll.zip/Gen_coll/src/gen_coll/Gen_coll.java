/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gen_coll;
import java.util.*;
public class Gen_coll {
    public static void main(String[] args) {
        // ArrayList example without generics
        ArrayList mylist=new ArrayList();
        mylist.add(0,"Hello");
        mylist.add(1,1234);
        mylist.add(2,true);
        mylist.add(3,new Integer(34));
                 
        //ArrayList example generics
        // munumlist.add(index,data);
        // in java 7 interface diamond is available
        // means the LHS def is equivalent to the RHS
        // generics are applied on the collection to make it type safe
        //ArrayList<Integer> mynumlist=new ArrayList<Integer>();
        //ArrayList<Integer> mynumlist=new ArrayList<>();
        ArrayList<Integer> mynumlist=new ArrayList();
        mynumlist.add(24234);
        mynumlist.add(24234);
        mynumlist.add(24234);
        //mynumlist.add("kjhkjh");
        // wrapper class
    Double d=new Double(87687.88);
    
       //here the reference is of list interface 
    // but the object is created of the arrayList
List<Integer> partList = new ArrayList<>();
partList.add(new Integer(1111));
partList.add(new Integer(3333));
partList.add(new Integer(2222)); //ArrayList auto   
partList.add(1,new Integer(2222)); //ArrayList auto   
partList.add(new Integer(4444));
partList.add(new Integer(4444));  //grows 
//System.out.println("First Part:" + partList.get(0)); // First item    
//partList.add(0, new Integer(5555));//Insert an item by index
  // int ---> primitive datatype (value)
    // int temp= wrapper reference type
    // unboxing ---> converting reference type to value type
    // boxing ----> converting value type to reference type
// enhanced for loop to read the collection
for(Integer mypart:partList )
{
int temp=mypart; // auto unboxing
//	int temp=(int)mypart; // explicit unboxing
//System.out.println("Part Number: " + temp ); 
System.out.println("Part Number: " +  mypart); 
}
 Integer i=23; // primitive boxing
      
    }
    
}
