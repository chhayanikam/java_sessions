/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gen_coll;

import java.util.*;

/**
 *
 * @author MRuser
 */
public class MapExample {
    public static void main(String a[])
    {
    Map <String, String> partList = new TreeMap<>();
   partList.put( "A001", "Blue Polo Shirt");
   partList.put( "C002", "Black Polo Shirt");
   partList.put( "B001", "Duke Hat");
   partList.put( "C002", "Black T- Shirt");//Overwrite value
   // keyset method return the key collection(first coloumn)
   Set<String> keys = partList.keySet();
   System.out.println("=== Part List ===");
   for (String key:keys)
   {
       // get is used to retrieve the data based on the key as a parameter
   System.out.println("Part#: "+ key + " " + partList.get(key));
   }

    }
}
