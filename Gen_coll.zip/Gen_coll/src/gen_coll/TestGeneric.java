/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gen_coll;
class CacheAny <T> // at runtime the datatype is replaced
  {    
  private T t;
  public void add(T t){
  this.t = t;
  } 
  public T get(){
  return this.t;
  }
  }
public class TestGeneric {
   public static void main(String args[])
  {
   //Generics
   CacheAny<String> myGenericMessage = new CacheAny<String>();
   CacheAny<Double> myGenericd = new CacheAny<Double>();
   myGenericMessage.add("Save this for me");
   myGenericd.add(34D);
 System.out.println(  myGenericMessage.get()); 
//System.out.println(  myMessage.get());
System.out.println(myGenericd.get());
   } 
}
